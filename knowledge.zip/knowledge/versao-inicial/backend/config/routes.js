/*jshint esversion: 9 */
module.exports = app => {
    app.route('/users')
        .post(app.api.user.save)  // api é a pasta
        .get(app.api.user.get);

    app.route('/users/:id')
        //.all(app.config.passport.authenticate())
        .put(app.api.user.save);
        //.get(admin(app.api.user.getById))
        //.delete(admin(app.api.user.remove));
};